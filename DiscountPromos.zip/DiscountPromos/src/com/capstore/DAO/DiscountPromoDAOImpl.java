package com.capstore.DAO;

import java.sql.Date;







import org.springframework.jdbc.core.JdbcTemplate;

import com.capstore.beans.Category;
import com.capstore.beans.Discount;
import com.capstore.beans.Product;
import com.capstore.beans.Promo;

public class DiscountPromoDAOImpl implements DiscountPromoDAO{
	
	JdbcTemplate jdbcTemplate;
	Product product= new Product();
	

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	Discount d=new Discount();
	Category c = new Category();

	@Override
	public int putDiscountOnProduct(Product[] products, int discount,
			Date expiryDate) {

		for(int i=0;i<products.length;i++)
		{
			String sql="insert into Discount values('"+d.getDiscount_Percentage()+"','"+d.getProduct_Id()+"')";
				    return jdbcTemplate.update(sql);  
		}
		return discount;
	}

	@Override
	public int putDiscountOnCategory(Category[] categories, int discount,
			Date expiryDate) {
		for(int i=0;i<categories.length;i++)
		{
			String sql="insert into category values('"+c.getCategory_Id()+"','"+c.getCategory_Name()+"')";
				    return jdbcTemplate.update(sql);  
		}
		return discount;
	}
	
	@Override
	public int putPromoOnProduct(Product products, int discount, Date expiryDate,int promoCode) {
		
		
			String sql="insert into Discount values('"+d.getDiscount_Percentage()+"','"+d.getProduct_Id()+"')";
				    return jdbcTemplate.update(sql);  
	
	}
	

	@Override
	public int putPromoOnCategory(int discount, int category_id,
			Date expiryDate,int promoCode) {
		
			String sql="insert into Discount values('"+d.getDiscount_Percentage()+"','"+d.getProduct_Id()+"')";
				    return jdbcTemplate.update(sql);  
		
	}

	
	
	


	
}