package com.capstore.DAO;

import java.util.Date;
import java.util.List;

import com.capstore.beans.Category;
import com.capstore.beans.Product;
import com.capstore.beans.Promo;

public interface DiscountPromoDAO {

	public int putDiscountOnProduct(Product[] products, int discount,
			java.sql.Date expiryDate);

	public int putDiscountOnCategory(Category[] categories, int discount,
			java.sql.Date expiryDate);

	public int putPromoOnCategory(int discount, int category_id,
			java.sql.Date expiryDate,int promoCode);

	public int putPromoOnProduct(Product products, int discount,java.sql.Date expiryDate,int promoCode);
	
	

	/*public int  putPromoOnProduct(Promo p);

	public int putDiscountOnCategory(Category[] categories, int discount,
			 Date expiryDate);

	public int putPromoOnProduct(int discount, int product_id,  Date expiryDate);

	public int putPromoOnCategory(int discount, int category_id,  Date expiryDate);
*/
}