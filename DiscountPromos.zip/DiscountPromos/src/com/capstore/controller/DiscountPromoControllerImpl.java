package com.capstore.controller;
import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstore.DAO.DiscountPromoDAO;
import com.capstore.beans.Category;
import com.capstore.beans.Discount;
import com.capstore.beans.Product;

@Controller
public class DiscountPromoControllerImpl{

	
	@Autowired
	DiscountPromoDAO dao;
	
	
	@RequestMapping(method= RequestMethod.GET)
	
	public String get()
	{
			return "first";	
	}
	@RequestMapping(method= {RequestMethod.POST}, params={"action=putDiscountOnProduct"})
	public String putDiscountOnProduct(@ModelAttribute("Products") Product[] products, @RequestParam("discount") int discount, @RequestParam("expiryDate") Date expiryDate)
	{
		
		if(dao.putDiscountOnProduct(products, discount, expiryDate)!=0)
			return "success";
		else
			return "failure";
	}
	
	@RequestMapping(method= RequestMethod.POST, params={"action=putDiscountOnCategory"})
	public String putDiscountOnCategory(@ModelAttribute("Category") Category[] categories, @RequestParam("discount") int discount, @RequestParam("expiryDate") Date expiryDate)
	{
		if(dao.putDiscountOnCategory(categories, discount, expiryDate)!=0)
			return "success";
		else
			return "failure";
	}
	
	@RequestMapping(method= RequestMethod.POST, params={"action=putPromoOnProduct"})
	public String putPromoOnProduct(@ModelAttribute("Products") Product products,@RequestParam("discount") int discount,@RequestParam("promoCode")int promoCode,@RequestParam("expiryDate") Date expiryDate)
	{
		int product_id=products.getProduct_Id();
		if(dao.putPromoOnProduct(products, discount, expiryDate,promoCode)!=0)
			return "success";
		else
			return "failure";
	}
	
	
	@RequestMapping(method= RequestMethod.POST, params={"action=putPromoOnCategory"})
	public String putPromoOnCategory(@ModelAttribute("Category") Category category, @RequestParam("discount") int discount, @RequestParam("PromoCode") int promoCode,@RequestParam("expiryDate") Date expiryDate)
	{
		int category_id=category.getCategory_Id();
		if(dao.putPromoOnCategory(discount, category_id, expiryDate, promoCode)!=0)
			return "success";
		else
			return "failure";
	}
	
	
	
	


}
