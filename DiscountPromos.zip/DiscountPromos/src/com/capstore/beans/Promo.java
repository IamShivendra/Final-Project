package com.capstore.beans;

import java.util.Date;
import javax.persistence.*;




public class Promo 
{
	
	
	private int discount;
	private Date expiryDate;
	private int productid;

	

	public Promo(int discount, Date expiryDate, int productid) {
		super();
	
		this.discount = discount;
		this.expiryDate = expiryDate;
		this.productid = productid;
	}
	

	


	





	
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}


	public int getDiscount() {
		return discount;
	}


	public void setDiscount(int discount) {
		this.discount = discount;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}








	
	
	
}
