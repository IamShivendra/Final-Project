package com.capstore.beans;


import java.sql.Date;

public class Discount {

	private int discount_Id;
	private int product_Id;
	private int category_Id;
	private boolean discount_Type;
	// [1 for normal_Discounts; 0 for Promos]
	private double discount_Percentage;
	

	public Discount(int discount_Id, int product_Id, int category_Id,
			boolean discount_Type, double discount_Percentage) {
		super();
		this.discount_Id = discount_Id;
		this.product_Id = product_Id;
		this.category_Id = category_Id;
		this.discount_Type = discount_Type;
		this.discount_Percentage = discount_Percentage;
	}

	public Discount() {
	}

	public int getDiscount_Id() {
		return discount_Id;
	}

	public void setDiscount_Id(int discount_Id) {
		this.discount_Id = discount_Id;
	}

	public int getProduct_Id() {
		return product_Id;
	}

	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}

	public int getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}

	

	public boolean isDiscount_Type() {
		return discount_Type;
	}

	public void setDiscount_Type(boolean discount_Type) {
		this.discount_Type = discount_Type;
	}


	public double getDiscount_Percentage() {
		return discount_Percentage;
	}

	public void setDiscount_Percentage(double discount_Percentage) {
		this.discount_Percentage = discount_Percentage;
	}

}
