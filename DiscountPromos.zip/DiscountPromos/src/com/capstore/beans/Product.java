package com.capstore.beans;

import java.sql.Date;

public class Product {

	private int product_Id;
	
	private int discount_Id;
	private int category_Id;
	private int product_id;
	private String product_Name;
	private String product_Description;
	private double product_Price;
	
	
	private  java.util.Date ExpiryDate;

	public Product() {
	}
	

	public Product(int product_Id, int merchant_Id, int discount_Id,
			int category_Id, String product_Name, String product_Description,
			double product_Price, String product_Image_Url,
			int product_Quantity_Left, int product_Quantity_Total,
			Date product_Insert_Date, int product_View_Count,
			java.util.Date expiryDate) {
		super();
		this.product_Id = product_Id;
		this.discount_Id = discount_Id;
		this.category_Id = category_Id;
		this.product_Name = product_Name;
		this.product_Description = product_Description;
		this.product_Price = product_Price;
		
		ExpiryDate = expiryDate;
	}


	public int getProduct_Id() {
		return product_Id;
	}

	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}

	

	public int getDiscount_Id() {
		return discount_Id;
	}

	public void setDiscount_Id(int discount_Id) {
		this.discount_Id = discount_Id;
	}

	public int getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}

	public String getProduct_Name() {
		return product_Name;
	}

	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}

	public String getProduct_Description() {
		return product_Description;
	}

	public void setProduct_Description(String product_Description) {
		this.product_Description = product_Description;
	}

	public double getProduct_Price() {
		return product_Price;
	}

	public void setProduct_Price(double product_Price) {
		this.product_Price = product_Price;
	}

	
	public java.util.Date getExpiryDate() {
		return ExpiryDate;
	}

	public void setExpiryDate(java.util.Date expiryDate2) {
		ExpiryDate = expiryDate2;
	}
	

	
	
}
